add_manager_success_result = """
<div class="alert alert-success" role="alert" style="text-align:center">
                                創建成功
</div>
"""

add_manager_warning_result = """
<div class="alert alert-warning" role="alert" style="text-align:center">
                                帳號已存在
</div>
"""

add_article_success_result = """
<div class="alert alert-success" role="alert" style="text-align:center">
                                寫入成功
</div>
"""

add_article_fail_result = """
<div class="alert alert-warning" role="alert" style="text-align:center">
                                寫入失敗
</div>
"""

lottery_code_checkbox_list_1 = """
<input id="item{}" type="checkbox" name="foo" value="{}" style="margin:5px" {}> {}
"""

lottery_code_checkbox_list_2 = """
<input id="item{}" type="checkbox" name="foo" value="{}" style="margin:5px" {}> {}
"""

option_value_dict = {
    'okmoney': '<option value="A1_nmn">nmn</option><option name="table_name" value="A1_estate">house</option>',
    'A1_estate': '<option value="A1_nmn">nmn</option><option name="table_name" value="A1_estate">house</option>',
    'A1_nmn': '<option value="A1_nmn">nmn</option><option name="table_name" value="A1_estate">house</option>',


                     }